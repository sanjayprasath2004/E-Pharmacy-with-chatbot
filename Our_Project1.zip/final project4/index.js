
// import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
// import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyD1wxRNIiYZGxrfGNCjvM1jiNQn1OYSw5M",
  authDomain: "easypharm-82073.firebaseapp.com",
  projectId: "easypharm-82073",
  storageBucket: "easypharm-82073.firebasestorage.app",
  messagingSenderId: "756950425409",
  appId: "1:756950425409:web:b91bbf6f3ed01f5eb04bc0",
  measurementId: "G-283W9QNVJS"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

const userGreeting = document.getElementById("userGreeting");
const loginBtn = document.getElementById("loginBtn");
const logoutBtn = document.getElementById("logoutBtn");

// Track last activity for session timeout
let logoutTimer;

const startLogoutTimer = () => {
  clearTimeout(logoutTimer);
  logoutTimer = setTimeout(() => {
    signOut(auth).then(() => {
      alert("You have been logged out due to inactivity.");
    });
  }, 30 * 60 * 1000); // 30 minutes
};

const resetTimerOnActivity = () => {
  document.addEventListener("mousemove", startLogoutTimer);
  document.addEventListener("keydown", startLogoutTimer);
  document.addEventListener("click", startLogoutTimer);
};
 
onAuthStateChanged(auth, (user) => {
if (user) {
const uid = user.uid;
const email = user.email;
const match = email.replace(/[^a-zA-Z].*$/, "");

userGreeting.textContent = `Hi, ${match}`;
loginBtn.style.display = "none";
logoutBtn.style.display = "inline-block";

// 👇 New code for profile image
const profileImg = document.getElementById("userProfileImage");
if (user.photoURL) {
profileImg.src = user.photoURL;
profileImg.style.display = "inline-block";
}

startLogoutTimer();
resetTimerOnActivity();
} else {
userGreeting.textContent = "";
loginBtn.style.display = "flex";
logoutBtn.style.display = "none";

const profileImg = document.getElementById("userProfileImage");
profileImg.style.display = "none";
clearTimeout(logoutTimer);
}
});
logoutBtn.addEventListener("click", () => {
  signOut(auth);
});


//


function searchMedicine() {
    var input = document.getElementById("searchInput").value.toLowerCase().trim();
    if (!input) {
      alert("Please enter a medicine name to search.");
      return;
    }

    var elderlyCareKeywords = ["diaper", "adult diaper", "liveasy", "knee", "knee cap", "pharmeasy knee cap", "multivitamin", "hk vitals", "fish oil", "apollo", "ensure", "protinex"];
    var diabeticCareKeywords = ["accu-chek", "smart blood glucose monitoring", "apollo", "ensure", "protinex"];

    if (diabeticCareKeywords.some(keyword => input.includes(keyword))) {
      window.location.href = "diabetic care.html";
    } else if (elderlyCareKeywords.some(keyword => input.includes(keyword))) {
      window.location.href = "Elderly Care.html";
    } else {
      alert("No matching medicines found. Try different keywords!");
    }
  }


  //
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });
  
  document.querySelectorAll('.review-card').forEach(el => {
    observer.observe(el);
  }); // ✅ Closed properly
  
  //
  const faqs = document.querySelectorAll(".faq");

  faqs.forEach(faq => {
    faq.addEventListener("click", () => {
      faq.classList.toggle("open");
    });
  });

  //
  function toggleChat() {
      var chatbot = document.getElementById('chatbot');
      chatbot.style.display = chatbot.style.display === 'none' ? 'block' : 'none';
  }

  function sendMessage() {
      var inputField = document.getElementById('user-input');
      var userText = inputField.value;
      if (!userText.trim()) return;
      
      var chatBody = document.getElementById('chat-body');
      chatBody.innerHTML += `<div><strong>You:</strong> ${userText}</div>`;
      inputField.value = '';
      setTimeout(() => respondToUser(userText.toLowerCase()), 1000);
  }

  function respondToUser(question) {
      var responses = {
          "hi": "Hello! This is Jira from Easy Pharmacy. How can I help you?",
          "what are your pharmacy hours": "We are open from 9 AM to 9 PM every day.",
          "do you deliver medicines": "Yes, we offer home delivery services.",
          "how can i contact customer support": "You can call us at +91-1234567890.",
          "do you have painkillers": "Yes, we have a variety of painkillers. Please consult a doctor before purchasing.",
          "how can i book a doctor appointment": "You can book a doctor appointment through our website's appointment section.",
          "do you offer lab tests": "Yes, we provide lab test services. You can schedule a test through our lab section.",
          "what types of lab tests do you provide": "We offer blood tests, urine tests, and many other diagnostic services.",
          "show the medicine page": "<a href='/medicine'>Click here to visit the medicine page</a>",
          "show the blog page": "<a href='/blog'>Click here to visit the blog page</a>",
          "take me to medicine page": "<a href='/medicine'>Click here to visit the medicine page</a>",
          "take me to health blog page": "<a href='/blog'>Click here to visit the blog page</a>",
          "can i book appointment with doctor": "Yes, you can book a slot with specialist doctors",
          "can you help in ordering medicines": "Yes, sure. You can select the category of medicine and add it to the cart.Then you can proceed to payment"
      };
      var chatBody = document.getElementById('chat-body');
      var response = responses[question] || "Sorry, I didn't understand. Please try another question.";
      chatBody.innerHTML += `<div><strong>Bot:</strong> ${response}</div>`;
  }