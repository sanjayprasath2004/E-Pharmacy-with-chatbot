// firebase-init.js

const firebaseConfig = {
    apiKey: "AIzaSyD1wxRNIiYZGxrfGNCjvM1jiNQn1OYSw5M",
    authDomain: "easypharm-82073.firebaseapp.com",
    projectId: "easypharm-82073",
    storageBucket: "easypharm-82073.appspot.com",
    messagingSenderId: "756950425409",
    appId: "1:756950425409:web:b91bbf6f3ed01f5eb04bc0",
    measurementId: "G-283W9QNVJS"
  };
  
  const app = firebase.initializeApp(firebaseConfig);
  const db = firebase.firestore();
  